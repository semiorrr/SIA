const API_KEY = '2e9b6f8db5a245408f972410252404';
const BASE_URL = 'https://api.weatherapi.com/v1/forecast.json';

const cityInput = document.getElementById('city-input');
const searchBtn = document.getElementById('search-btn');
const weatherResult = document.getElementById('weather-result');
const loading = document.getElementById('loading');
const error = document.getElementById('error');
const cityName = document.getElementById('city-name');
const weatherIcon = document.getElementById('weather-icon');
const temperature = document.getElementById('temperature');
const weatherDescription = document.getElementById('weather-description');
const humidity = document.getElementById('humidity');
const windSpeed = document.getElementById('wind-speed');
const forecastContainer = document.getElementById('forecast-container');

searchBtn.addEventListener('click', fetchWeather);

async function fetchWeather() {
    const city = cityInput.value.trim();
    
    if (!city) {
        showError('Please enter a city name');
        return;
    }

    loading.classList.remove('hidden');
    weatherResult.classList.add('hidden');
    error.classList.add('hidden');

    try {
        const response = await fetch(`${BASE_URL}?key=${API_KEY}&q=${encodeURIComponent(city)}&days=5`);
        if (!response.ok) throw new Error('Network error');

        const data = await response.json();
        if (data.error) throw new Error(data.error.message || 'Weather data not available');

        displayWeather(data);
    } catch (err) {
        showError(err.message || 'Failed to fetch weather data');
    } finally {
        loading.classList.add('hidden');
    }
}

function displayWeather(data) {
    const current = data.current;
    const location = data.location;

    cityName.textContent = `${location.name}, ${location.country}`;
    temperature.textContent = `${current.temp_c}°C`;
    weatherDescription.textContent = current.condition.text;
    humidity.textContent = `Humidity: ${current.humidity}%`;
    windSpeed.textContent = `Wind: ${current.wind_kph} km/h`;

    const weatherGif = getWeatherGif(current.condition.text);
    weatherIcon.src = `images/${weatherGif}`;
    weatherIcon.alt = current.condition.text;

    // Clear previous forecast
    forecastContainer.innerHTML = '';

    // Display 5-day forecast
    data.forecast.forecastday.forEach(day => {
        const date = new Date(day.date);
        const dayName = date.toLocaleDateString('en-US', { weekday: 'short' });
        const forecastGif = getWeatherGif(day.day.condition.text);

        const dayElement = document.createElement('div');
        dayElement.className = 'forecast-day';

        dayElement.innerHTML = `
            <div class="forecast-date">${dayName}</div>
            <img src="images/${forecastGif}" alt="${day.day.condition.text}" class="forecast-icon">
            <div class="forecast-temp">${day.day.avgtemp_c}°C</div>
            <div class="forecast-desc">${day.day.condition.text}</div>
        `;

        forecastContainer.appendChild(dayElement);
    });

    weatherResult.classList.remove('hidden');
}

function getWeatherGif(description) {
    const desc = description.toLowerCase();

    if (desc.includes('sunny') || desc.includes('clear')) {
        return 'sunny.gif';
    } else if (desc.includes('partly cloudy')) {
        return 'partly-cloudy.gif';
    } else if (desc.includes('cloud')) {
        return 'cloudy.gif';
    } else if (desc.includes('rain')) {
        return 'rainy.gif';
    } else if (desc.includes('snow')) {
        return 'snowy.gif';
    } else if (desc.includes('thunder') || desc.includes('storm')) {
        return 'thunderstorm.gif';
    } else if (desc.includes('fog') || desc.includes('mist')) {
        return 'foggy.gif';
    } else if (desc.includes('overcast')) {
        return 'overcast.gif';
    } else {
        return 'default.gif';
    }
}

function showError(message) {
    error.textContent = message;
    error.classList.remove('hidden');
}
